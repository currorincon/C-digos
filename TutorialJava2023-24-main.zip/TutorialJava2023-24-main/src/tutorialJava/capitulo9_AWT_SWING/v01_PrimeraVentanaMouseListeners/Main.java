package tutorialJava.capitulo9_AWT_SWING.v01_PrimeraVentanaMouseListeners;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main  {
	
	
	public static void main(String[] args) {
		VentanaPrincipal ventanaPrincipal = new VentanaPrincipal ();
		ventanaPrincipal.setVisible(true);
	}
}

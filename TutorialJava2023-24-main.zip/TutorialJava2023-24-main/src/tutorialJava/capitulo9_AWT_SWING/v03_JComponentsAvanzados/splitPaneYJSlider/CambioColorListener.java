package tutorialJava.capitulo9_AWT_SWING.v03_JComponentsAvanzados.splitPaneYJSlider;

import java.awt.Color;

public interface CambioColorListener {

	public void cambioColor (CambioColorEvent evento);
}

package tutorialJava.capitulo9_AWT_SWING.v04_GestionEntidadManejadaPorJPA;

public class Main  {
	
	
	public static void main(String[] args) {
		VentanaPrincipal ventanaPrincipal = new VentanaPrincipal ();
		ventanaPrincipal.setVisible(true);
	}
}

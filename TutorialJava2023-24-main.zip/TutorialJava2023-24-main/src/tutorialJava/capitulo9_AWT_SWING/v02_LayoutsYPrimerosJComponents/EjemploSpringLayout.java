package tutorialJava.capitulo9_AWT_SWING.v02_LayoutsYPrimerosJComponents;

import javax.swing.JPanel;

public class EjemploSpringLayout extends JPanel {
	
	/**
	 * 
	 */
	public EjemploSpringLayout () {
		
	}

}

package tutorialJava.capitulo7_Recursos.palabraRepetidaException;

public class PalabraRepetidaException extends Exception {

	public PalabraRepetidaException() {
		super();
	}

	public PalabraRepetidaException(String message) {
		super(message);
	}

}

package tutorialJava.capitulo7_Recursos.ejemploNumeroImparListener;

public interface NumeroImparListener {

	public void numeroImparIntroducido(NumeroImparEvent e);
}

package tutorialJava.capitulo7_Recursos.ejemploPalabraRepetidaEnFraseListener;

public interface PalabraRepetidaListener {
	
	public void palabraRepetidaEncontrada(PalabraRepetidaEvent e);
}

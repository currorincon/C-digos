package tutorialJava.capitulo7_Recursos.excepciones;

public class PersonaNulaException extends Exception {

	public PersonaNulaException(String msg) {
        super(msg);
    }
}

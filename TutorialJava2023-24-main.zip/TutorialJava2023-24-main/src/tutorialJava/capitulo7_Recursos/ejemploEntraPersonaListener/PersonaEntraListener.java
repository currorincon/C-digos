package tutorialJava.capitulo7_Recursos.ejemploEntraPersonaListener;

public interface PersonaEntraListener {

	public void entraPersona(PersonaEntraEvent e);
}

package tutorialJava.examenes.examen_20240130.ejercicio3;

public interface EventoMeteorologicoListener {
	public void comienzaALlover();
	public void terminaDeLlover();
}

package tutorialJava.examenes.examen_20231205_arrays_objetos.baloncesto;

public class Principal {

	public static void main(String[] args) {
		Partido p = new Partido();
		p.juega();
		p.estadisticas();
		
		System.out.println();
	}

}

package tutorialJava.capitulo5.poker;

public class Principal {

	public static void main (String args[]) {
		Poker poker = new Poker();		
		
		System.out.println();
	}
}












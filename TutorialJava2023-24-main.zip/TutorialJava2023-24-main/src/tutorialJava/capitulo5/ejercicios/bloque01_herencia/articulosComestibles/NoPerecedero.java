package tutorialJava.capitulo5.ejercicios.bloque01_herencia.articulosComestibles;

public class NoPerecedero extends Articulo {

	public NoPerecedero() {
		super();
	}
}


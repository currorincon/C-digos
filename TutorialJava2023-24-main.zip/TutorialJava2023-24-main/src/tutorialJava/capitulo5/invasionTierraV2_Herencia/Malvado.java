package tutorialJava.capitulo5.invasionTierraV2_Herencia;

import tutorialJava.Utils;

public class Malvado extends Personaje {
	
	
	
	@Override
	public String toString() {
		return "Malvado=" + super.toString();
	}
	
}

package tutorialJava.capitulo1;

public class Ejemplo01_HolaMundo {

	public static void main(String[] args) {
		System.out.println("Hola Mundo4");
	}      
  
}

package tutorialJava.modelosBasesDeDatosComunesJPA;

public abstract class Entidad {

	public Entidad () {
		super();
	}
	
	public abstract int getId();	
}

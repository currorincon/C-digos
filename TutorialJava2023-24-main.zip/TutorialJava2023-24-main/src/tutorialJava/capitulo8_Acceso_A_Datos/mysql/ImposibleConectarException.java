package tutorialJava.capitulo8_Acceso_A_Datos.mysql;

public class ImposibleConectarException extends Exception {

	public ImposibleConectarException(String message) {
		super(message);
	}

	
}
